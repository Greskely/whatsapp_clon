import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'estados_screen.dart';
import 'llamadas_screen.dart';
import 'camara_screen.dart';

class BottomNavScreen extends StatefulWidget {
  const BottomNavScreen({Key? key}) : super(key: key);

  @override
  State<BottomNavScreen> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNavScreen> {
  // controla el indice seleccinado para mostrar la vista correspondiente
  int _indiceSeleccionado = 0;
// controla el widget que se mostrará en pantalla
  Widget _currBody = ChatScreen();

  //metodo que recibe el indice de seleccion para cambiar de pantalla
  void _onItemTapped(int index) {
    setState(() {
      _indiceSeleccionado = index;

      switch (_indiceSeleccionado) {
        case 0:
          _currBody = CamaraScreen();
          break;

        case 1:
          _currBody = ChatScreen();
          break;
        case 2:
          _currBody = EstadosScreen();
          break;
        case 3:
          _currBody = LlamadasScreen();
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    //final args = ModalRoute.of(context)!.settings.arguments as Argument;

    return Scaffold(
      //AppBar principal que muestra el titulo de la aplicaion y widget de tipo action
      //los botones buscar y menú no tienen funcionalidad
      appBar: AppBar(title: const Text('WhatsApp'), actions: <Widget>[
        IconButton(
          icon: const Icon(Icons.search),
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {},
        ),
      ]),
      body: _currBody,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed, // Fixed
        backgroundColor: Colors.teal[800], // <-- This works for fixed
        selectedItemColor: Colors.tealAccent[400],
        unselectedItemColor: Colors.blueGrey[100],

        //items para selección de la barra de navegación
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.camera_alt),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.message),
            label: 'CHATS',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.motion_photos_on),
            label: 'ESTADOS',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.call),
            label: 'LLAMADAS',
          ),
        ],
        currentIndex: _indiceSeleccionado,
        onTap: _onItemTapped,
      ),
    );
  }
}
