import 'package:flutter/material.dart';

class Contacto {
  final String nombre;
  final String subtitulo;

  Contacto(this.nombre, this.subtitulo);
}

class EstadosScreen extends StatelessWidget {
  EstadosScreen({Key? key}) : super(key: key);

  final List<Contacto> _contactos = [
    Contacto("Madre", "Hoy 11:00 a.m"),
    Contacto("Gary", "Hoy 3:15 p.m"),
    Contacto("Neysi", "Ayer 5:00 p.m"),
    Contacto("Karelys", "Ayer 6:10 p.m"),
    Contacto("Papá", "Ayer 7:45 a.m"),
    Contacto("Lisseth", "Hoy 8:00 p.m"),
    Contacto("Doña Iva", "Hoy 9:15 p.m"),
    Contacto("Tia Liliam", "Hoy 2:00 p.m"),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
            onPressed: () {}, //
            child: const Icon(Icons.camera_alt) //
            ),
        body: ListView.builder(
            itemCount: _contactos.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                  //ICONO QUE SIMULA FOTO DE PERFIL DEL CONTACTO
                  leading: const Icon(Icons.motion_photos_on),
                  //Muestra el nombre del contacto
                  title: Text(_contactos[index].nombre),
                  //texto de ejemplo para simular fecha y hora de actualizacion de estado
                  subtitle: Text(_contactos[index].subtitulo));
            }));
  }
}
