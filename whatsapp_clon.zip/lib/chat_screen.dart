import 'package:flutter/material.dart';

//import 'list_view.dart';
class Contacto {
  final String nombre;
  final String mensaje;

  Contacto(this.nombre, this.mensaje);
}

class ChatScreen extends StatelessWidget {
  ChatScreen({Key? key}) : super(key: key);

  final List<Contacto> _contactos = [
    Contacto("Madre", "Hola hija, que haces?"),
    Contacto("Gary", "Iremos la cine"),
    Contacto("Neysi", "Podemos salir el sabado"),
    Contacto("Karelys", "Vamos a trabajar en el proyecto hoy?"),
    Contacto("Papá", "Hija, ya estas en casa?"),
    Contacto("Lisseth", "Irás a clases"),
    Contacto("Doña Iva", "Mañana, la veo"),
    Contacto("Tia Liliam", "Mañana llego"),
    Contacto("Doc.Pedro", "Ok, gracias"),
    Contacto("Anielka", "Hasta luego"),
    Contacto("Julio", "Muchas gracias"),
    Contacto("Tia Tere", "Linda mi niña"),
    Contacto("Name", "*****MESSAGE*****"),
    Contacto("Name", "*****MESSAGE*****"),
    Contacto("Name", "*****MESSAGE*****"),
    Contacto("Name", "*****MESSAGE*****"),
    Contacto("Name", "*****MESSAGE*****")
  ];

  @override
  Widget build(BuildContext context) {
    //final args = ModalRoute.of(context)!.settings.arguments as Contacto;

    return Scaffold(
      floatingActionButton: FloatingActionButton(onPressed: () {}, child: const Icon(Icons.message)),
      body: ListView.builder(
          itemCount: _contactos.length,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
                //ICONO QUE SIMULA FOTO DE PERFIL DEL CONTACTO
                leading: const Icon(Icons.contact_phone),
                title: Text(_contactos[index].nombre),
                subtitle: Text(_contactos[index].mensaje));
          }),
    );
  }
}
