import 'package:flutter/material.dart';
import 'bottom_nav.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'WhatsApp',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),

      // A widget which will be started on application startup
      home: BottomNavScreen(),
    );
  }
}

/*class MyHomePage extends StatelessWidget {
  final String title;
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text(title),
        /*bottom: TabBar(tabs: <Widget>[
          Tab(
            text: "LLAMADAS",
          ),
          Tab(
            text: "CHAT",
          ),
          Tab(
            text: "ESTADOS",
          ),
        ]),*/
        /*actions: <Widget>[
          IconButton(icon: Icon(Icons.search), onPressed: () {}),
          IconButton(icon: Icon(Icons.message), onPressed: () {}),
          IconButton(icon: Icon(Icons.more_vert), onPressed: () {})
        ],
      ),
      body: Center(
        child: Text(
          'Hello, World!',
        ),
      ),
    );
  }
}*/*/
