import 'package:flutter/material.dart';

class Contacto {
  final String nombre;
  final String subtitulo;

  Contacto(this.nombre, this.subtitulo);
}

class LlamadasScreen extends StatelessWidget {
  LlamadasScreen({Key? key}) : super(key: key);

  final List<Contacto> _contactos = [
    Contacto("Madre", "Ayer 8:00 a.m"),
    Contacto("Gary", "20 de mayo 9:15 p.m"),
    Contacto("Neysi", "13 de mayo 6:45 p.m"),
    Contacto("Karelys", "06 de mayo 7:00 "),
    Contacto("Papá", "18 de abril 11:19 a.m"),
    Contacto("Lisseth", "15 de abril 4:15 p.m"),
    Contacto("Doña Iva", "8 de abril 3:00 p.m"),
    Contacto("Tia Liliam", "01 de abril 1:00 p.m "),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(onPressed: () {}, child: const Icon(Icons.add_ic_call)),
        body: ListView.builder(
            itemCount: _contactos.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                  //ICONO QUE SIMULA FOTO DE PERFIL DEL CONTACTO
                  leading: const Icon(Icons.image_rounded),
                  //Muestra el nombre del contacto
                  title: Text(_contactos[index].nombre),
                  //texto de ejemplo para simular fecha y hora de llamada
                  subtitle: Text(_contactos[index].subtitulo),
                  trailing: const Icon(Icons.call));
            }));
  }
}
