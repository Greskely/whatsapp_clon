import 'package:flutter/material.dart';

class CamaraScreen extends StatelessWidget {
  const CamaraScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        /*floatingActionButton: FloatingActionButton(
      onPressed: () {},*/
        //child: const Icon(Icons.message),
        ); //);
  }
}
