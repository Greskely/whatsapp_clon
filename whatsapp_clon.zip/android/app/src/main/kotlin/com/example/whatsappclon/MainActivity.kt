package com.example.whatsappclon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
